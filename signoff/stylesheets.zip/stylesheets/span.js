import { StyleSheet } from "react-native";

export const TextStyle =StyleSheet.create({
    bold:{
        fontWeight: 'bold'
    },
    underline:{
        textDecorationLine :'underline',
    }
})